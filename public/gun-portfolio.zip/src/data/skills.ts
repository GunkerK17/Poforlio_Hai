export interface SkillItem {
  id: string;
  number: string;
  name: string;
  subSkills: string[];
  description: string;
  photoKey: string;
  accent: string;
}

export const skillsData: SkillItem[] = [
  {
    id: "football",
    number: "01",
    name: "FOOTBALL",
    subSkills: ["Chiến thuật thi đấu", "Huấn luyện chuyên sâu", "Kỷ luật & Thể lực"],
    description: "Tư duy vị trí sắc bén, khả năng lãnh đạo đội hình và kinh nghiệm hơn 6 năm tôi luyện từ lò đào tạo trẻ chuyên nghiệp.",
    photoKey: "IMG_7934.JPG",
    accent: "#FF5A1F",
  },
  {
    id: "technology",
    number: "02",
    name: "TECHNOLOGY",
    subSkills: ["Web Development", "UI / UX Design", "AI Tools & APIs"],
    description: "Xây dựng các sản phẩm số hiện đại với React, TypeScript, Tailwind, RESTful API và công nghệ AI thế hệ mới.",
    photoKey: "att.z4FaEGg355ZZkQ2bUWi6vR2Sn2nxXhDkf_KXj08dQZw.jpg",
    accent: "#3B82F6",
  },
  {
    id: "sales",
    number: "03",
    name: "SALES",
    subSkills: ["Giải pháp FPT Telecom", "Tư vấn nhu cầu thực", "Chăm sóc khách hàng"],
    description: "Lắng nghe, thấu hiểu bài toán kết nối của từng gia đình và doanh nghiệp để đề xuất hạ tầng Internet, truyền hình và an ninh tối ưu.",
    photoKey: "IMG_3712.JPG",
    accent: "#F59E0B",
  },
  {
    id: "content",
    number: "04",
    name: "CONTENT",
    subSkills: ["Short-form Video", "Kể chuyện thương hiệu", "CapCut & Media"],
    description: "Ghi lại hành trình thật từ sân bóng đến bàn làm việc, lan tỏa năng lượng tích cực và thông điệp sống kỷ luật đến cộng đồng.",
    photoKey: "IMG_3784.JPG",
    accent: "#EC4899",
  },
];
