import React, { useState } from "react";
import { ArrowUpRight, ArrowRight, Award, GraduationCap, Briefcase, Calendar } from "lucide-react";
import { AuthenticPhoto } from "../ui/AuthenticPhoto";

export const Story: React.FC = () => {
  const [selectedMilestone, setSelectedMilestone] = useState<number | null>(null);

  const journeyCards = [
    {
      period: "2010 - 2016",
      title: "Bắt đầu với bóng đá",
      subtitle: "Những năm đầu, nuôi dưỡng đam mê bóng đá từ nhỏ.",
      photoKey: "IMG_9587.JPG",
      alt: "Thời niên thiếu khởi đầu áo đỏ sân cỏ",
      tagColor: "bg-[#FF5A1F]",
      details: [
        "Những bước chạy đầu tiên trên mặt sân cỏ quê hương An Giang.",
        "Rèn luyện kỹ thuật cơ bản, thể lực và xây dựng tình yêu thuần khiết với trái bóng tròn.",
        "Thi đấu các giải đấu thiếu nhi, hội khỏe phù đổng và cúp Milo.",
      ],
    },
    {
      period: "2016 - 2020",
      title: "Thi đấu chuyên nghiệp",
      subtitle: "Khoảng 6 năm thi đấu tại CLB An Giang.",
      photoKey: "IMG_5663.JPG",
      alt: "Tuyến trẻ CLB An Giang sân Long Xuyên",
      tagColor: "bg-[#FF5A1F]",
      details: [
        "Ăn tập chuyên nghiệp tại Trung tâm Huấn luyện & Thi đấu CLB An Giang.",
        "Thi đấu các giải trẻ Quốc gia U15, U17, U19 và giải chuyên nghiệp.",
        "Tôi luyện tinh thần thép, kỷ luật thể thao đỉnh cao và sự hy sinh vì tập thể.",
      ],
    },
    {
      period: "2020 - 2024",
      title: "Tốt nghiệp đại học",
      subtitle: "Công nghệ Thông tin FPT University Cần Thơ.",
      photoKey: "IMG_9161.JPG",
      alt: "Lễ tốt nghiệp FPT University Cần Thơ",
      tagColor: "bg-[#FF5A1F]",
      details: [
        "Chuyển hướng học tập chuyên ngành Kỹ thuật Phần mềm & Công nghệ Thông tin.",
        "Đội trưởng số 18 dẫn dắt tuyển bóng đá FPT University Cần Thơ.",
        "Đạt danh hiệu Vua phá lưới VUG 10 Cần Thơ 2024 với phong độ xuất sắc.",
      ],
    },
    {
      period: "Hiện tại",
      title: "Công việc & Đam mê",
      subtitle: "FPT Telecom ban ngày và HLV bóng đá buổi tối.",
      photoKey: "IMG_3698.JPG",
      alt: "Áo số 18 Hải FPT",
      tagColor: "bg-[#FF5A1F]",
      details: [
        "Ban ngày: Chuyên viên tư vấn giải pháp mạng Internet Wi-Fi 6, FPT Play & Camera AI.",
        "Buổi tối & Cuối tuần: Huấn luyện bóng đá trẻ em, đào tạo học viên phong trào tại Cần Thơ.",
        "Phát triển các dự án công nghệ quản lý giải đấu và chia sẻ kiến thức.",
      ],
    },
  ];

  return (
    <section id="story" className="py-20 md:py-28 bg-[#F5F3EE] text-[#101010]">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div className="max-w-xl">
            <span className="font-mono text-xs font-bold tracking-widest text-[#FF5A1F] uppercase block mb-2">
              01. HÀNH TRÌNH CỦA TÔI
            </span>
            <h2 className="font-display font-black text-3xl sm:text-4xl md:text-5xl text-[#101010] tracking-tight">
              Từ sân cỏ đến cuộc sống hiện tại.
            </h2>
            <p className="mt-3 text-sm md:text-base text-neutral-600 font-light leading-relaxed">
              Mỗi giai đoạn đều là một trải nghiệm quý giá, giúp mình trở thành phiên bản tốt hơn của hôm nay.
            </p>
          </div>

          <button
            onClick={() => setSelectedMilestone(0)}
            className="inline-flex items-center gap-2 text-xs md:text-sm font-bold text-[#101010] hover:text-[#FF5A1F] transition-colors py-2 border-b-2 border-neutral-300 hover:border-[#FF5A1F] self-start md:self-end cursor-pointer"
          >
            <span>Xem chi tiết</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {/* 4 Cards Horizontal Grid matching mockup */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {journeyCards.map((card, idx) => (
            <div
              key={idx}
              onClick={() => setSelectedMilestone(idx)}
              className="group cursor-pointer rounded-2xl overflow-hidden bg-white shadow-md hover:shadow-xl transition-all duration-300 flex flex-col justify-between border border-neutral-200 hover:border-[#FF5A1F]/40"
            >
              <div>
                {/* Photo Header */}
                <div className="relative w-full h-48 bg-neutral-900 overflow-hidden">
                  <AuthenticPhoto
                    photoKey={card.photoKey}
                    alt={card.alt}
                    aspectRatio="custom"
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  {/* Period Badge */}
                  <div className="absolute bottom-3 left-3">
                    <span className="px-2.5 py-1 bg-[#FF5A1F] text-white font-mono text-[11px] font-bold rounded-md shadow-sm">
                      {card.period}
                    </span>
                  </div>
                </div>

                {/* Content */}
                <div className="p-5">
                  <h3 className="font-display font-black text-lg text-[#101010] group-hover:text-[#FF5A1F] transition-colors">
                    {card.title}
                  </h3>
                  <p className="mt-1.5 text-xs text-neutral-600 leading-relaxed font-light">
                    {card.subtitle}
                  </p>
                </div>
              </div>

              {/* Card Footer */}
              <div className="px-5 pb-5 pt-2 flex items-center justify-between text-xs font-mono text-neutral-400 group-hover:text-[#FF5A1F] transition-colors">
                <span>Khám phá mốc này</span>
                <ArrowUpRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Milestone Modal */}
      {selectedMilestone !== null && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="relative w-full max-w-lg bg-[#141A29] text-white rounded-2xl overflow-hidden border border-white/15 p-6 sm:p-8 shadow-2xl">
            <button
              onClick={() => setSelectedMilestone(null)}
              className="absolute top-4 right-4 p-2 bg-white/10 hover:bg-[#FF5A1F] rounded-full text-white transition-colors cursor-pointer"
            >
              ✕
            </button>

            <span className="px-2.5 py-1 bg-[#FF5A1F] text-white font-mono text-xs font-bold rounded">
              {journeyCards[selectedMilestone].period}
            </span>

            <h3 className="font-display font-black text-2xl text-white mt-3">
              {journeyCards[selectedMilestone].title}
            </h3>
            <p className="text-xs text-neutral-400 font-mono mt-1">
              {journeyCards[selectedMilestone].subtitle}
            </p>

            <div className="my-5 rounded-xl overflow-hidden h-52 bg-black border border-white/10">
              <AuthenticPhoto
                photoKey={journeyCards[selectedMilestone].photoKey}
                alt={journeyCards[selectedMilestone].alt}
                aspectRatio="custom"
                className="w-full h-full object-cover"
              />
            </div>

            <div className="space-y-2 text-xs text-neutral-300 font-light leading-relaxed">
              {journeyCards[selectedMilestone].details.map((d, i) => (
                <div key={i} className="flex items-start gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#FF5A1F] shrink-0 mt-1" />
                  <span>{d}</span>
                </div>
              ))}
            </div>

            <div className="mt-6 flex justify-between items-center pt-4 border-t border-white/10">
              <button
                disabled={selectedMilestone === 0}
                onClick={() => setSelectedMilestone((prev) => (prev !== null && prev > 0 ? prev - 1 : prev))}
                className="text-xs font-mono text-neutral-400 hover:text-white disabled:opacity-30 cursor-pointer"
              >
                ← Mốc trước
              </button>
              <button
                disabled={selectedMilestone === journeyCards.length - 1}
                onClick={() => setSelectedMilestone((prev) => (prev !== null && prev < journeyCards.length - 1 ? prev + 1 : prev))}
                className="text-xs font-mono text-[#FF5A1F] hover:text-white disabled:opacity-30 cursor-pointer"
              >
                Mốc tiếp theo →
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
