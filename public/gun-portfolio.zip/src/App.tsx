import React, { useState } from "react";
import { Navbar } from "./components/layout/Navbar";
import { Hero } from "./components/hero/Hero";
import { Story } from "./components/story/Story";
import { Skills } from "./components/skills/Skills";
import { Projects } from "./components/projects/Projects";
import { Products } from "./components/products/Products";
import { ContentLife } from "./components/content/ContentLife";
import { Contact } from "./components/contact/Contact";
import { Footer } from "./components/layout/Footer";
import { AdminDrawer } from "./components/admin/AdminDrawer";
import { ConsultationModal } from "./components/ui/ConsultationModal";
import { BatchPhotoModal } from "./components/ui/BatchPhotoModal";
import { StudentRegistrationModal } from "./components/ui/StudentRegistrationModal";
import { profileData } from "./data/profile";
import { Phone, MessageCircle, Sparkles, Image as ImageIcon } from "lucide-react";

export default function App() {
  const [adminOpen, setAdminOpen] = useState(false);
  const [photoBatchOpen, setPhotoBatchOpen] = useState(false);
  const [studentModalOpen, setStudentModalOpen] = useState(false);
  const [consultationModalOpen, setConsultationModalOpen] = useState(false);
  const [consultationProduct, setConsultationProduct] = useState("Internet FPT");
  const [contactTopic, setContactTopic] = useState<string>("FPT Telecom / Tư vấn mạng");

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: "smooth" });
    }
  };

  const handleOpenConsultation = (productName?: string) => {
    if (productName) setConsultationProduct(productName);
    setConsultationModalOpen(true);
  };

  return (
    <div className="min-h-screen bg-[#F5F3EE] text-[#101010] selection:bg-[#FF5A1F] selection:text-white relative">
      {/* Top Banner for 1-Click Photo Sync and Code Download */}
      <div className="bg-[#0b0d13] text-[#F5F3EE] text-xs font-mono py-2.5 px-4 border-b border-white/10 text-center flex flex-wrap items-center justify-center gap-4 relative z-50">
        <span className="flex items-center gap-1.5 text-neutral-300">
          <Sparkles className="w-3.5 h-3.5 text-[#FF5A1F]" />
          <span>Website Nguyễn Chí Hải (GUN) đã hoàn thiện 100%</span>
        </span>

        <button
          onClick={() => setPhotoBatchOpen(true)}
          className="text-[#FF5A1F] hover:text-white transition-colors cursor-pointer flex items-center gap-1 font-semibold underline"
        >
          <span>📸 Nạp 15 ảnh thật</span>
        </button>

        <span className="hidden sm:inline text-neutral-600">|</span>

        <a
          href="/gun-portfolio.zip"
          download="gun-portfolio.zip"
          className="px-3 py-1 bg-[#FF5A1F] hover:bg-[#e04e18] text-white rounded font-bold transition-colors cursor-pointer flex items-center gap-1 shadow-sm"
        >
          <span>📥 Tải file ZIP toàn bộ website về máy</span>
        </a>
      </div>

      {/* Global Navigation Header */}
      <Navbar
        onOpenContact={() => scrollToSection("contact")}
        onOpenAdmin={() => setAdminOpen(true)}
        onOpenPhotoBatch={() => setPhotoBatchOpen(true)}
      />

      {/* 01. Hero Section matching mockup with credentials bar */}
      <Hero
        onExplore={() => scrollToSection("story")}
        onConnect={() => scrollToSection("contact")}
      />

      {/* 02. 01. HÀNH TRÌNH CỦA TÔI (4-Card Horizontal Timeline) */}
      <Story />

      {/* 03. 02. KỸ NĂNG (4 Vertical Cards on Dark Background) */}
      <Skills />

      {/* 04. 03. DỰ ÁN / CÔNG VIỆC NỔI BẬT (FPT, Trung tâm bóng đá, Web/App) */}
      <Projects
        onOpenConsultation={handleOpenConsultation}
        onOpenStudentModal={() => setStudentModalOpen(true)}
      />

      {/* 05. 04. SẢN PHẨM & DỊCH VỤ (Internet, FPT Play, Camera FPT) */}
      <Products onOpenConsultation={handleOpenConsultation} />

      {/* 06. 05. CONTENT / LIFE (4 Video Cards with View Counts & Filters) */}
      <ContentLife />

      {/* 07. 06. KẾT NỐI VỚI TÔI (Sunset Stadium, #10 GUN, Social Links) */}
      <Contact
        initialTopic={contactTopic}
        onOpenConsultation={() => handleOpenConsultation("Tư vấn trực tiếp cùng Hải")}
      />

      {/* 08. Footer matching mockup */}
      <Footer />

      {/* Floating Action Buttons */}
      <div className="fixed bottom-6 right-6 z-40 flex flex-col items-end gap-3">
        {/* Quick Photo Sync floating pill */}
        <button
          onClick={() => setPhotoBatchOpen(true)}
          className="flex items-center gap-2 px-3 py-2 bg-[#101010] text-[#F5F3EE] hover:bg-[#FF5A1F] text-xs font-mono rounded-full shadow-2xl transition-all cursor-pointer border border-white/10"
          title="Nạp 15 ảnh thật từ máy"
        >
          <ImageIcon className="w-4 h-4 text-[#FF5A1F]" />
          <span className="hidden sm:inline">Nạp 15 ảnh</span>
        </button>

        <div className="flex items-center gap-2.5">
          <a
            href={profileData.contact.zaloUrl}
            target="_blank"
            rel="noreferrer"
            title="Nhắn Zalo cho Hải"
            className="w-12 h-12 rounded-full bg-[#0068FF] text-white flex items-center justify-center shadow-2xl hover:scale-110 transition-transform cursor-pointer"
          >
            <MessageCircle className="w-6 h-6" />
          </a>

          <a
            href={`tel:${profileData.contact.phone}`}
            title="Gọi Hotline"
            className="w-12 h-12 rounded-full bg-[#FF5A1F] text-white flex items-center justify-center shadow-2xl hover:scale-110 transition-transform cursor-pointer"
          >
            <Phone className="w-5 h-5" />
          </a>
        </div>
      </div>

      {/* Admin / Photo Management Drawer */}
      <AdminDrawer isOpen={adminOpen} onClose={() => setAdminOpen(false)} />

      {/* 1-Click Batch Photo Matcher Modal */}
      <BatchPhotoModal
        isOpen={photoBatchOpen}
        onClose={() => setPhotoBatchOpen(false)}
      />

      {/* Football Student Enrollment Modal */}
      <StudentRegistrationModal
        isOpen={studentModalOpen}
        onClose={() => setStudentModalOpen(false)}
      />

      {/* FPT Telecom Consultation Modal */}
      <ConsultationModal
        isOpen={consultationModalOpen}
        onClose={() => setConsultationModalOpen(false)}
        productName={consultationProduct}
      />
    </div>
  );
}
